$(document).ready(function() {
    $('#zoom1').zoom({
        url: "DroneCowsLarge.jpg"
    });

    $('#zoom2').zoom({
        url: "SnowTractor.jpg"
    });
});